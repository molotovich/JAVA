public class Personita extends Persona {
	String papa;
	String mama;
}