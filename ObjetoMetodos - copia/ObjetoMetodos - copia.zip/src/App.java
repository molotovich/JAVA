public class App {
    public static void main(String[] args) {
        Persona persona1 = new Persona();
        persona1.capturaSexo();

    /*  System.out.println("Aqui van los datos de la persona2");
        System.out.println(persona2.direccion);
        System.out.println(persona2.edad);
        System.out.println(persona2.nombre);*/
        System.out.println(persona1.sexo); 
    }
}